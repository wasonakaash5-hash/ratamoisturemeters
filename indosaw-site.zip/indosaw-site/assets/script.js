document.addEventListener('DOMContentLoaded', () => {
  // mobile nav toggle
  const toggle = document.getElementById('navToggle');
  const links = document.getElementById('navLinks');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('open');
      links.classList.toggle('open');
    });
    links.querySelectorAll('a:not(.drop-menu a)').forEach(a => a.addEventListener('click', () => {
      toggle.classList.remove('open');
      links.classList.remove('open');
    }));
  }

  // products dropdown (click-to-toggle on touch/mobile, hover on desktop via CSS)
  document.querySelectorAll('.drop > button').forEach(btn => {
    btn.addEventListener('click', () => {
      const drop = btn.closest('.drop');
      drop.classList.toggle('open');
    });
  });

  // single orchestrated reveal for grid sections
  const revealTargets = document.querySelectorAll('.reveal');
  if (revealTargets.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealTargets.forEach(t => io.observe(t));
  }

  // product category filter (products page)
  const filterButtons = document.querySelectorAll('.cat-filter button');
  const productCards = document.querySelectorAll('.product-card');
  if (filterButtons.length) {
    filterButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        filterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.dataset.cat;
        productCards.forEach(card => {
          card.style.display = (cat === 'all' || card.dataset.cat === cat) ? 'flex' : 'none';
        });
      });
    });
  }
});

function handleFormSubmit(e){
  e.preventDefault();
  alert('Thanks — this is a static demo form. Connect it to your email service or a form backend (e.g. Formspree) once this is live.');
  return false;
}
