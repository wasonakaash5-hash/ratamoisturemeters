document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('footer-placeholder');
  if (!el) return;
  el.innerHTML = `
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <h5>INDOSAW</h5>
          <p>Manufacturing laboratory and agricultural equipment from Punjab, India, since 1993. Trusted by institutions across the country and exported abroad.</p>
        </div>
        <div>
          <h5>COMPANY</h5>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="products.html">Products</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div>
        <div>
          <h5>DIVISIONS</h5>
          <ul>
            <li><a href="https://www.indosawedu.com" target="_blank" rel="noopener">Indosaw Edu</a></li>
            <li><a href="https://indosawagri.com" target="_blank" rel="noopener">Indosaw Agri</a></li>
            <li><a href="https://www.therheostat.com" target="_blank" rel="noopener">Rheostat (Contrex)</a></li>
            <li><a href="https://inspirephysics.com" target="_blank" rel="noopener">Inspire Physics (UK)</a></li>
          </ul>
        </div>
        <div>
          <h5>CONTACT</h5>
          <ul>
            <li><a href="tel:+919896092926">+91-9896092926</a></li>
            <li><a href="tel:01712699347">0171-2699347</a></li>
            <li><a href="mailto:info@indosaw.in">info@indosaw.in</a></li>
            <li>Punjab, India</li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>Copyright © 2026 Indosaw. All rights reserved.</p>
        <span class="fmark">MADE IN PUNJAB SINCE 1993</span>
      </div>
    </div>
  `;
});
